set define '^' verify off
prompt ...wwv_flows_release
create or replace function wwv_flows_release wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
69 92
GpLUYlN5ctjp6YsFYdM7Qp6N7EUwg8eZgcfLCNL+XhaWlm2u2fqWlkqW8tehLlbcXOfAsr2y
m17nx3TAM7h0ZQm4dIvmOdziuUE/cZ5nqcoOo3cugXSBWdJ0dNJ0Vnc7vnFzcdiIppWjBDk=


/
