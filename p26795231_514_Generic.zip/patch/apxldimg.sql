Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      apxldimg.sql
Rem
Rem    DESCRIPTION
Rem      This script will load Application Express images into XDB.
Rem
Rem    NOTES
Rem      This script should be run as SYS.
Rem
Rem    Arguments:
Rem      Position 1: The path to the directory where the Application Express patch exists on
Rem                  the filesystem.
Rem
Rem    Example:
Rem      sqlplus "sys/syspass as sysdba" @apxldimg.sql /tmp/patch
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem     jkallman   01/02/2013 - Created
Rem     vuvarov    04/05/2013 - Added support for empty files
Rem     vuvarov    04/15/2013 - Reference script arguments only once
Rem     jstraub    02/03/2014 - Invoke apxldimg_core.sql


set define '^' verify off
set serveroutput on
set concat on
set concat .

Rem Check SYSDBA Privilege
whenever sqlerror exit
begin
    for c1 in (
        select null
          from sys.session_privs
         where privilege = 'SYSDBA'
    ) loop
        return;
    end loop;

    sys.dbms_output.put_line('Error: Please execute this script as SYS.' );
    execute immediate 'bogus statement to force exit';
end;
/
whenever sqlerror continue

@@apxpreins.sql

COLUMN :script_name NEW_VALUE comp_file NOPRINT
VARIABLE script_name VARCHAR2(50)

declare
    l_script_name varchar2(100);
begin
    if '^CDB_ROOT' = 'YES' then
        l_script_name := 'apxldimg_cdb.sql';
    elsif '^CDB' = 'YES' and '^META_LINK' = 'METADATA LINK' then
        l_script_name := 'apxldimg_cdb.sql';
    else
        l_script_name := 'apxldimg_nocdb.sql';
    end if;
    :script_name := l_script_name;
end;
/

select :script_name from dual;

@@^comp_file ^1 x
