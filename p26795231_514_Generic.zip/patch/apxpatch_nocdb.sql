Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      apxpatch_nocdb.sql
Rem
Rem    DESCRIPTION
Rem      This script is called by apxpatch.sql and *SHOULD NOT BE RUN* directly.
Rem
Rem    NOTES
Rem      Assumes the SYS user is connected.
Rem
Rem    REQUIREMENTS
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem     vuvarov    12/22/2016 - Created
Rem     vuvarov    03/29/2017 - Updated for APEX 5.1.2
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4

spool apxpatch.log

set define '^' verify off
set concat on
set concat .

define PREFIX       = '@'
define INSTALL_TYPE = 'MANUAL'

@^PREFIX.patches/5_1_4/prereq.sql

timing start "Complete Patch"

@^PREFIX.patches/5_1_4/syspatch.sql ^PREFIX ^INSTALL_TYPE
@^PREFIX.patches/5_1_4/ddlpatch.sql ^PREFIX ^INSTALL_TYPE
@^PREFIX.patches/5_1_4/deppatch.sql ^PREFIX ^INSTALL_TYPE
@^PREFIX.patches/5_1_4/corepatch.sql ^PREFIX ^INSTALL_TYPE

timing stop
