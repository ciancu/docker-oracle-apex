set define '^' verify off
prompt ...patch_24410383.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_24410383.sql
--
--    DESCRIPTION
--      Amend page item value required setting and item template on 4850:3
--
--    MODIFIED   (MM/DD/YYYY)
--    hfarrell    03/01/2017 - Created
--
--------------------------------------------------------------------------------


begin
    wwv_flow_security.g_security_group_id := 10;
	    
	  select value into wwv_flow_api.g_nls_numeric_chars from nls_session_parameters where parameter='NLS_NUMERIC_CHARACTERS';
	  execute immediate 'alter session set nls_numeric_characters=''.,''';

    -- Updating English translation setting
    update wwv_flow_step_items
       set is_required = 'Y',
           item_field_template = 719737577300952641
     where flow_id             = 4850
       and flow_step_id        = 3
       and id                  = 829958421128351764 
       and security_group_id    = 10;
       
    -- Updating non-English languages
	  for c1 in (select id from wwv_flows where id between 4850 and 4859) loop
	      update wwv_flow_step_items
	         set is_required = 'Y',
               item_field_template = 719737577300952641||'.'||c1.id
	       where flow_id = c1.id
	         and flow_step_id = 3||'.'||c1.id
	         and id = 829958421128351764||'.'||c1.id
           and security_group_id = 10;    
	    end loop;
	
	    execute immediate 'alter session set nls_numeric_characters='''||wwv_flow_api.g_nls_numeric_chars||'''';
	    commit;       
end;
/