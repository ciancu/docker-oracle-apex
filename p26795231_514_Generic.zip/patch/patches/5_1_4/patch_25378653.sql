set define '^' verify off
prompt ...patch_25378653.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25378653.sql
--
--    DESCRIPTION
--      Fixes pkg app upgrade wizard to show error
--
--    MODIFIED   (MM/DD/YYYY)
--    cbcho       01/12/2017 - Created
--
--------------------------------------------------------------------------------

begin
    wwv_flow_security.g_security_group_id := 10;

    select value into wwv_flow_api.g_nls_numeric_chars from nls_session_parameters where parameter='NLS_NUMERIC_CHARACTERS';
    execute immediate 'alter session set nls_numeric_characters=''.,''';
end;
/

-- 4750:265 Change the last step of pkg app upgrade
begin
    -- Close the upgrade wizard dialog only if there is no error
    update wwv_flow_step_processing
    set process_when_type = 'FUNCTION_BODY',
        process_when = wwv_flow_string.join(wwv_flow_t_varchar2(
                       'declare',
                       '    l_error_cnt number := 0;',
                       'begin',
                       '    select count(*)',
                       '    into l_error_cnt',
                       '    from htmldb_collections',
                       '    where collection_name = ''APEX_DEPLOYMENT_LOG_''||:P262_ID',
                       '    and c002 = ''FAIL'';',
                       '',
                       '    if l_error_cnt = 0 then',
                       '        return true; -- all done close dialog',
                       '    else',
                       '        return false; -- go view error',
                       '    end if;',
                       'end;'))
    where flow_id between 4750 and 4759
    and flow_step_id >= 265
    and flow_step_id <  265 + 1
    and id >= 1187116845296203401
    and id <  1187116845296203401 + 1;

    -- Add branch if there is failure during upgrade
    for c1 in (select null from dual where not exists (select 1 from wwv_flow_step_branches where flow_id = 4750 and id = 2576713939645373214))
    loop
        wwv_flow_api.create_page_branch(
         p_id=>2576713939645373214
        ,p_flow_id=>4750
        ,p_flow_step_id=>265
        ,p_branch_name=>'failure'
        ,p_branch_action=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:::'
        ,p_branch_point=>'AFTER_PROCESSING'
        ,p_branch_type=>'REDIRECT_URL'
        ,p_branch_sequence=>40
        ,p_branch_condition_type=>'EXISTS'
        ,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
        'select null',
        'from htmldb_collections',
        'where collection_name = ''APEX_DEPLOYMENT_LOG_''||:P262_ID',
        'and c002 = ''FAIL'''))
        );
    end loop;

    for c1 in (select id from wwv_flows where id between 4751 and 4759)
    loop
        for c2 in (select null from dual where not exists (select 1 from wwv_flow_step_branches where flow_id = c1.id and id = 2576713939645373214||'.'||c1.id))
        loop
            wwv_flow_api.create_page_branch(
                 p_id=>2576713939645373214||'.'||c1.id
                ,p_flow_id=>c1.id
                ,p_flow_step_id=>265||'.'||c1.id
                ,p_branch_name=>'failure'
                ,p_branch_action=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:::'
                ,p_branch_point=>'AFTER_PROCESSING'
                ,p_branch_type=>'REDIRECT_URL'
                ,p_branch_sequence=>40
                ,p_branch_condition_type=>'EXISTS'
                ,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
                'select null',
                'from htmldb_collections',
                'where collection_name = ''APEX_DEPLOYMENT_LOG_''||:P262_ID',
                'and c002 = ''FAIL'''))
                );
        end loop;
    end loop;
end;
/

-- 4750:210 Change region source to include error message from upgrade
begin
    -- Supporting Objects Install Error region condtion
    update wwv_flow_page_plugs
    set plug_display_when_condition = wwv_flow_string.join(wwv_flow_t_varchar2(
    'select null',
    'from htmldb_collections',
    'where collection_name in ( ''APEX_DEPLOYMENT_LOG_''||:P83_NEW_APP_ID, ''APEX_DEPLOYMENT_LOG_''||:P262_ID )',
    'and c001 = ''PREREQ_CHECK'''))
    where flow_id between 4750 and 4759
    and page_id >= 210
    and page_id <  210 + 1
    and id >= 656909453831982642
    and id <  656909453831982642 + 1;
    
    -- Install Summary region source
    update wwv_flow_page_plugs
    set plug_source = wwv_flow_string.join(wwv_flow_t_varchar2(
    'select c001 script_name, ',
    '       decode(c002, ''SUCCESS'', ',
    '                    wwv_flow_lang.system_message(''INSTALLER.SCRIPT.SUCCESS''),',
    '                    ''FAIL'',',
    '                    wwv_flow_lang.system_message(''INSTALLER.SCRIPT.FAIL'')) status,        ',
    '       to_number(nvl(c003,0)) fail_count,',
    '       to_number(nvl(c004,0)) success_count,',
    '       c003 + c004 total_count',
    '  from htmldb_collections',
    ' where collection_name in ( ''APEX_DEPLOYMENT_LOG_''||:P83_NEW_APP_ID, ''APEX_DEPLOYMENT_LOG_''||:P262_ID )',
    ' and c001 != ''PREREQ_CHECK'''))
    where flow_id between 4750 and 4759
    and page_id >= 210
    and page_id <  210 + 1
    and id >= 656998326917093004
    and id <  656998326917093004 + 1;
    
    -- Supporting object errors region source
    update wwv_flow_page_plugs
    set plug_source = wwv_flow_string.join(wwv_flow_t_varchar2(
    'begin',
    'for c1 in (select c001 script_name, clob001 errors ',
    '           from htmldb_collections ',
    '           where collection_name in ( ''APEX_DEPLOYMENT_LOG_''||:P83_NEW_APP_ID, ''APEX_DEPLOYMENT_LOG_''||:P262_ID )',
    '           and c001 != ''PREREQ_CHECK''',
    '           and length(clob001) > 0)',
    'loop',
    '  sys.htp.p(''<b>''||wwv_flow_escape.html(c1.script_name)||''</b>'');',
    '  sys.htp.p(''<pre>'');',
    '  wwv_flow_sw_script.escape_sc_clob(c1.errors);',
    '  sys.htp.p(''</pre>'');',
    'end loop;',
    'end;'))
    where flow_id between 4750 and 4759
    and page_id >= 210
    and page_id <  210 + 1
    and id >= 657004620656135228
    and id <  657004620656135228 + 1;
    
    -- Prerequisite Check Failed region condition
    update wwv_flow_page_plugs
    set plug_display_when_condition = wwv_flow_string.join(wwv_flow_t_varchar2(
    'select null',
    'from htmldb_collections',
    'where collection_name in ( ''APEX_DEPLOYMENT_LOG_''||:P83_NEW_APP_ID, ''APEX_DEPLOYMENT_LOG_''||:P262_ID )',
    'and c001 = ''PREREQ_CHECK'''))
    where flow_id between 4750 and 4759
    and page_id >= 210
    and page_id <  210 + 1
    and id >= 1136583887364333643
    and id <  1136583887364333643 + 1;
    
    -- Prerequisite Check errors region source
    update wwv_flow_page_plugs
    set plug_source = wwv_flow_string.join(wwv_flow_t_varchar2(
    'for c1 in (select c001 script_name, clob001 errors ',
    '           from htmldb_collections ',
    '           where collection_name in ( ''APEX_DEPLOYMENT_LOG_''||:P83_NEW_APP_ID, ''APEX_DEPLOYMENT_LOG_''||:P262_ID )',
    '           and c001 = ''PREREQ_CHECK''',
    '           and length(clob001) > 0)',
    'loop',
    '    -- note: wwv_flow_pkg_app_install.prereq_check_bf_install populates formatted message with HTML tag if prerequisite check fails, don''t escape',
    '    sys.htp.p( c1.errors );',
    'end loop;'))
    where flow_id between 4750 and 4759
    and page_id >= 210
    and page_id <  210 + 1
    and id >= 1136583922609333644
    and id <  1136583922609333644 + 1;
end;
/

commit
/

begin
execute immediate 'alter session set nls_numeric_characters='''||wwv_flow_api.g_nls_numeric_chars||'''';
commit;
end;
/


