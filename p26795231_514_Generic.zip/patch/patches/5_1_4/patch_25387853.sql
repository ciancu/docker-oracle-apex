set define '^' verify off
prompt ...patch_25387853.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25387853.sql
--
--    DESCRIPTION
--      Change page branch condtion for page 4000:4703
--
--    MODIFIED   (MM/DD/YYYY)
--    cbcho       01/13/2017 - Created
--
--------------------------------------------------------------------------------


begin

    update wwv_flow_step_branches
       set branch_condition_type = null,
           branch_condition = null
     where flow_id between 4000 and 4009
       and flow_step_id >= 4703
       and flow_step_id < 4703 + 1
       and id >= 137480688414 
       and id < 137480688414 + 1
       and security_group_id = 10;
end;
/
commit
/
