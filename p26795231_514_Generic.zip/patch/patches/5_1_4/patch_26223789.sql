set define '^' verify off
prompt ...patch_26223789.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_26223789.sql
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  06/07/2017 - Created
--   cneumuel  06/08/2017 - Private synonym v
--
--------------------------------------------------------------------------------

prompt ...flows_files.wwv_flow_security
declare
    e_not_granted exception;
    pragma exception_init(e_not_granted, -1927);
begin
    execute immediate 'revoke execute on wwv_flow_security from FLOWS_FILES';
exception when e_not_granted then null;
end;
/
declare
    e_does_not_exist exception;
    pragma exception_init(e_does_not_exist, -1434);
begin
    execute immediate 'drop synonym flows_files.wwv_flow_security';
exception when e_does_not_exist then null;
end;
/
prompt ...flows_files.v
grant execute on v to flows_files;
declare
    e_name_used exception;
    pragma exception_init(e_name_used, -955);
begin
    execute immediate 'create synonym flows_files.v for v';
exception when e_name_used then null;
end;
/


prompt ...trigger wwv_biu_flow_file_objects

create or replace trigger FLOWS_FILES.wwv_biu_flow_file_objects
    before insert or update on wwv_flow_file_objects$
    for each row
begin
    if inserting then
        :new.created_by := nvl(wwv_flow.g_user,user);
        :new.created_on := sysdate;
        wwv_flow_file_object_id.g_id := :new.id;
        wwv_flow_file_api.g_file_inserted := true;
        wwv_flow_file_api.g_file_inserted_count := wwv_flow_file_api.g_file_inserted_count + 1;
    elsif updating then
        :new.updated_by := nvl(wwv_flow.g_user,user);
        :new.updated_on := sysdate;
        wwv_flow_file_object_id.g_id := :new.id;
    end if;
    --
    if :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if :new.flow_id is null then
        :new.flow_id := 0;
    end if;
    :new.filename := substr(:new.name,instr(:new.name,'/')+1);
    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(v('APP_SECURITY_GROUP_ID'),0);
    end if;
end;
/
show errors
