set define '^' verify off
prompt ...patch_25227883.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25227883.sql
--
--    DESCRIPTION
--      fix multiple issues making "CREATE REPORT ON WEBSERVICE" wizard unusable
--      affected pages: 4000:778, 4000:782, 4000:786, 4000:860
--
--    MODIFIED   (MM/DD/YYYY)
--    cczarski     10/01/2017 - Created
--
--------------------------------------------------------------------------------

--
-- fixes for page 778
--

-- fix dynamic action: item P778_NODE_PATH is not hidden when "WSDL" is selected
update wwv_flow_page_da_actions 
   set AFFECTED_ELEMENTS = 'P778_REST_WS_ID,P778_MAN_WS_ID,P778_MAN_SOAP_STYLE,P778_MAN_MSG_FORMAT,P778_MAN_MSG_NAMESAPECE,P778_NODE_PATH'
 where flow_id             between 4000 and 4009
   and page_id              >= 778
   and page_id              <  778 + 1
   and id                   >= 272279541790934721 
   and id                   <  272279541790934721 + 1
   and security_group_id    =  10;
	
-- fix item P778_WSDL_OPERATION_ID using wrong LOV
update wwv_flow_step_items 
   set named_lov = null,
       lov       = wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select wwv_flow_escape.html(name) d, id r',
'  from wwv_flow_ws_operations',
' where name != ''BASIC_AUTH''',
'   and ws_id = :P778_WSDL_WS_ID'))
 where flow_id             between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 253079085401538049 
   and id                   <  253079085401538049 + 1
   and security_group_id    =  10;

-- fix item P778_WSDL_ARRAY using wrong LOV
update wwv_flow_step_items 
   set named_lov = null,
       lov       = wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select wwv_flow_escape.html(name)||'' (''||wwv_flow_escape.html(parm_type)||'')'' d, id r',
'  from wwv_flow_ws_parameters a',
' where type_is_xsd = ''N''',
'   and input_or_output = ''O''',
'   and exists (select 1',
'                 from wwv_flow_ws_parameters',
'                where parent_id = a.id',
'                  and type_is_xsd = ''Y'')', 
'   and ws_opers_id = :P778_WSDL_OPERATION_ID'))
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 253079152835538050 
   and id                   <  253079152835538050 + 1
   and security_group_id    =  10;

-- fix conditions and associated items for all validations
update wwv_flow_step_validations
   set validation_condition2 = 782
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 272278414019934710 
   and id                   <  272278414019934710 + 1
   and security_group_id    =  10;

update wwv_flow_step_validations
   set validation_condition2 = 783
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 272278607658934712 
   and id                   <  272278607658934712 + 1
   and security_group_id    =  10;


update wwv_flow_step_validations
   set validation_condition2 = 860
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 272278139063934707 
   and id                   <  272278139063934707 + 1
   and security_group_id    =  10;

update wwv_flow_step_validations
   set validation_condition2 = 782,
       validation             = 'P778_WSDL_WS_ID'
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 272278276818934708 
   and id                   <  272278276818934708 + 1
   and security_group_id    =  10;


update wwv_flow_step_validations
   set validation_condition2 = 783,
       validation             = 'P778_MAN_WS_ID'
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 272278302865934709 
   and id                   <  272278302865934709 + 1
   and security_group_id    =  10;

update wwv_flow_step_validations
   set validation_condition2 = 782,
       validation             = 'nvl(:P778_WSDL_OPERATION_ID,''0'') != ''0'''
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 778
   and flow_step_id         <  778 + 1
   and id                   >= 272278576072934711 
   and id                   <  272278576072934711 + 1
   and security_group_id    =  10;

--
-- Fixes for Page 782
--/

-- fix item P782_ARRAY using wrong source item and wrong LOV
update wwv_flow_step_items 
   set source = 'P778_WSDL_ARRAY',
       named_lov = null,
       lov       = wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select wwv_flow_escape.html(name)||'' (''||wwv_flow_escape.html(parm_type)||'')'' d, id r',
'  from wwv_flow_ws_parameters a',
' where type_is_xsd = ''N''',
'   and input_or_output = ''O''',
'   and exists (select 1',
'                 from wwv_flow_ws_parameters',
'                where parent_id = a.id',
'                  and type_is_xsd = ''Y'')', 
'   and ws_opers_id = :P778_WSDL_OPERATION_ID'))
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 782
   and flow_step_id         <  782 + 1
   and id                   >= 114112010206435537 
   and id                   <  114112010206435537 + 1
   and security_group_id    =  10;

-- fix source for region "Create &P759_REPORT_TITLE." 
update wwv_flow_page_plugs
   set plug_source = wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select wwv_flow_item.checkbox(1,id,null,:P782_CHECKED_ITEMS) x, ',
'       name, parm_type',
'  from wwv_flow_ws_parameters',
' where type_is_xsd = ''Y''',
'   and parent_id = :P778_WSDL_ARRAY'))
 where flow_id         between 4000 and 4009
   and page_id              >= 782
   and page_id              <  782 + 1
   and id                   >= 114109628559435534 
   and id                   <  114109628559435534 + 1
   and security_group_id    =  10;

--
-- Fixes for Page 786
-- 

-- fix source for process "create report on ws page"
declare
    l_code varchar2(32767);
begin
    l_code := wwv_flow_utilities.join(wwv_flow_t_varchar2(
'declare',
'  l_report_temp  varchar2(4000) := null;',
'  l_rows_per_pg  varchar2(4000) := null;',
'  l_sql          varchar2(32000);',
'begin',
'  if :P778_WEB_REF_TYPE = ''782'' then',
'    ',
'    l_sql := wwv_flow_web_services.generate_query(',
'                p_operation_id              => :P778_WSDL_OPERATION_ID,',
'                p_array_parm                => :P778_WSDL_ARRAY,',
'                p_report_collection_name    => :P782_RESULT_COLLECTION,',
'                p_array_parms_collection    => ''WS_ARRAY_PARMS'' );  ',
'',
'    l_report_temp := :P782_ROW_TEMPLATE;       ',
'    l_rows_per_pg := :P782_ROWS_PER_PAGE;',
'',
'  elsif :P778_WEB_REF_TYPE = ''860'' then',
'    ',
'  l_sql := wwv_flow_web_services.generate_query(',
'                p_operation_id              => :P778_REST_OPERATION_ID,',
'                p_array_parm                => null,',
'                p_report_collection_name    => :P860_RESULT_COLLECTION,',
'                p_array_parms_collection    => ''WS_ARRAY_PARMS'' );',
'',
'    l_report_temp := :P860_ROW_TEMPLATE;       ',
'    l_rows_per_pg := :P860_ROWS_PER_PAGE;',
'',
'  else',
'',
'    l_sql := wwv_flow_web_services.generate_query_manual(',
'                p_result_node               => :P778_NODE_PATH,',
'                p_soap_style                => :P778_MAN_SOAP_STYLE,',
'                p_message_format            => :P778_MAN_MSG_FORMAT,',
'                p_namespace                 => :P778_MAN_MSG_NAMESAPECE,',
'                p_report_collection_name    => :P783_RESULT_COLLECTION,',
'                p_array_parms_collection    => ''WS_REPORT_ITEMS'');    ',
'',
'    l_report_temp := :P783_ROW_TEMPLATE;                 ',
'    l_rows_per_pg := :P783_ROWS_PER_PAGE;     ',
'               ',
'  end if;        ',
'  ',
'  ',
'  wwv_flow_wizard_api.create_report_on_ws(',
'      p_flow_id                  => :FB_FLOW_ID,',
'      p_page_id                  => :P759_PAGE_ID,',
'      p_page_name                => :P759_PAGE_NAME,',
'      p_group_name               => null,',
'      p_page_mode                => :P759_PAGE_MODE,',
'      p_user_interface_id        => :P259_USER_INTERFACE_ID,',
'      p_region_name              => :P759_PAGE_NAME,',
'      p_region_template          => wwv_flow_theme_dev.get_region_template_id (',
'                                        p_application_id => :FB_FLOW_ID,',
'                                        p_theme_id       => :FB_THEME_ID,',
'                                        p_page_type      => :P259_CHOOSE_PAGE_TYPE),',
'      --',
'      p_tab_set                  => :P4716_TAB_SET,',
'      p_tab_name                 => :P4716_TAB_NAME,',
'      p_tab_text                 => :P4716_TAB_LABEL,',
'      --',
'      p_nav_list_id              => :P4716_NAVLIST_ID,',
'      p_nav_list_parent_item_id  => :P4716_NAVLIST_PARENT_ID,',
'      p_nav_list_child_item_name => :P4716_NAVLIST_ENTRY_NAME,',
'      --',
'      p_report_template          => l_report_temp,',
'      p_rows_per_page            => nvl(l_rows_per_pg,''15''),',
'      --',
'      p_breadcrumb_id            => :P759_BREADCRUMB_ID,',
'      p_breadcrumb_name          => :P759_BREADCRUMB_NAME,',
'      p_parent_bc_id             => :P759_BREADCRUMB_PARENT_ID,',
'      --',
'      p_query                    => l_sql );',
'',
'  :fb_flow_page_id       := :P759_PAGE_ID;',
'  :f4000_p4150_goto_page := :P759_PAGE_ID;',
'  :F4000_RUN_EDIT_PAGE   := :P759_PAGE_ID;',
'end;'));

update wwv_flow_step_processing
   set process_sql_clob = l_code 
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 786
   and flow_step_id         <  786 + 1
   and id                   >= 114623110840640138 
   and id                   <  114623110840640138 + 1
   and security_group_id    =  10;
end;
/

-- fix "back" button action
update wwv_flow_step_buttons
   set button_redirect_url = 'f?p=&APP_ID.:782:&SESSION.::&DEBUG.:RP::',
       button_action       = 'REDIRECT_PAGE'
 where flow_id         between 4000 and 4009
   and flow_step_id         >= 786
   and flow_step_id         <  786 + 1
   and id                   >= 114159214433504879 
   and id                   <  114159214433504879 + 1
   and security_group_id    =  10;

--
-- Fixes for Page 860
--

-- fix source for region "Create &P759_REPORT_TITLE." 
update wwv_flow_page_plugs
   set plug_source = wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select wwv_flow_item.checkbox(1,id,''title="''||wwv_flow_lang.system_message(''SELECT_ROW_C'', wwv_flow_escape.html(name))||''"'',:P860_CHECKED_ITEMS) x, ',
'       name, parm_type',
'  from wwv_flow_ws_parameters',
' where ws_opers_id = :P778_REST_OPERATION_ID',
'   and input_or_output = ''O'''))
 where flow_id         between 4000 and 4009
   and page_id              >= 860
   and page_id              <  860 + 1
   and id                   >= 193942426256118931 
   and id                   <  193942426256118931 + 1
   and security_group_id    =  10;


commit
/
