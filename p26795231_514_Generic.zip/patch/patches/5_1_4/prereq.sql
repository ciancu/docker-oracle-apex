set define '^' verify off
set serveroutput on

Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     12/22/2016 - Created prerequisite checks for 5.1.1 patch
Rem    vuvarov     03/29/2017 - Updated for APEX 5.1.2
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4

define APPVER = '5.1.4.00.08'

whenever sqlerror exit sql.sqlcode rollback

prompt Verifying Application Express version...
declare
    c_prev_releases   constant varchar2(255) := ':5.1.0.00.45:5.1.1.00.08:5.1.2.00.09:5.1.3.00.05:';
    c_current_version constant varchar2(255) := sys.dbms_registry.version('APEX');
    c_patch_version   constant varchar2(255) := '^APPVER.';
begin
    sys.dbms_output.put_line('...have version ' || c_current_version);

    if instr(c_prev_releases, ':' || c_current_version || ':') > 0 then
        return;
    elsif c_current_version between regexp_replace(c_patch_version, '\.([0-9]*)$', '.01') and c_patch_version then
        return;
    end if;

    raise_application_error(-20001, 'This script can only be used to patch the following releases: ' ||
        replace(trim(':' from c_prev_releases), ':', ', ') || '.');
end;
/

whenever sqlerror continue
