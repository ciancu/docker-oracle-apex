set define '^' verify off
prompt ...patch_26802765.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_26802765.sql
--
--    DESCRIPTION
--      Change page branch for page 4500:10
--
--    MODIFIED   (MM/DD/YYYY)
--    cbcho       09/27/2017 - Created
--
--------------------------------------------------------------------------------


begin

    update wwv_flow_step_branches
       set branch_name = 'Go To Page 1225',
           branch_action = 'f?p=&APP_ID.:1225:&SESSION.::&DEBUG.:RP,1225:P1224_RESULT_ID:&P10_RESULT_ID.&success_msg=#SUCCESS_MSG#'
     where flow_id between 4500 and 4509
       and flow_step_id >= 10
       and flow_step_id < 10 + 1
       and id >= 471472722487546596 
       and id < 471472722487546596 + 1
       and security_group_id = 10;
end;
/
commit
/
