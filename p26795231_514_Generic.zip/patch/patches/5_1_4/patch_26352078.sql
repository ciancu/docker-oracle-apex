set define '^' verify off
prompt ...patch_26352078_dev.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_26352078_dev.sql
--
--    DESCRIPTION
--      Builder change to include wwv_flow_region_columns LOV in copy page wizard
--
--    MODIFIED   (MM/DD/YYYY)
--    cbcho      06/29/2017 - Created
--
--------------------------------------------------------------------------------

-- 
-- Fix for page 622:
-- fix branch condition to 623 to include wwv_flow_region_columns
--
update wwv_flow_step_branches
   set branch_condition = wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1      ',
'from (select distinct i.named_lov lov_name, ',
'               i.flow_id,',
'               i.flow_step_id page_id,              ',
'               r.plug_name region,',
'               i.name used',
'    from wwv_flow_step_items i, wwv_flow_page_plugs r',
'    where i.flow_id = :P621_COPY_FROM_FLOW_ID and ',
'          i.flow_step_id = :P621_COPY_FROM_PAGE_ID and',
'          r.page_id = i.flow_step_id and',
'          r.flow_id = i.flow_id and',
'          i.item_plug_id = r.id and',
'          i.named_lov is not null     ',
'    union    ',
'    select distinct l.lov_name lov_name,',
'           c.flow_id flow_id,',
'           r.page_id page_id,',
'           r.plug_name region,',
'           c.column_alias used',
'    from wwv_flow_region_report_column c, wwv_flow_page_plugs r, wwv_flow_lists_of_values$ l',
'    where c.flow_id = :P621_COPY_FROM_FLOW_ID and',
'          r.page_id = :P621_COPY_FROM_PAGE_ID and',
'          c.region_id = r.id and',
'          c.named_lov = l.id and',
'          r.flow_id = c.flow_id    ',
'    union',
'    select distinct k.lov_name lov_name, ',
'           m.flow_id flow_id,',
'           m.page_id page_id,',
'           n.name region,',
'           m.DB_COLUMN_NAME used',
'    from wwv_flow_worksheet_columns m, wwv_flow_lists_of_values$ k, WWV_FLOW_WORKSHEETS n',
'    where m.flow_id = :P621_COPY_FROM_FLOW_ID and',
'          n.page_id = :P621_COPY_FROM_PAGE_ID and',
'          m.rpt_named_lov = k.id and',
'          m.worksheet_id = n.id and',
'          n.flow_id = m.flow_id ',
'    union',
'    select distinct l.lov_name lov_name,',
'           c.flow_id flow_id,',
'           r.page_id page_id,',
'           r.plug_name region,',
'           c.name used',
'    from wwv_flow_region_columns c, wwv_flow_page_plugs r, wwv_flow_lists_of_values$ l',
'    where c.flow_id = :P621_COPY_FROM_FLOW_ID and',
'          r.page_id = :P621_COPY_FROM_PAGE_ID and',
'          c.region_id = r.id and',
'          ( c.lov_id = l.id or c.filter_lov_id = l.id ) and',
'          r.flow_id = c.flow_id ) l'))
where flow_id between 4000 and 4009
  and flow_step_id >= 622
  and flow_step_id < 622 + 1
  and id >= 200891622822238088 
  and id < 200891622822238088 + 1
  and security_group_id = 10;

-- 
-- Fix for page 623:
-- fix Copy Lists of Values to include wwv_flow_region_columns
--
declare
    l_code clob;
begin
    l_code := wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  q varchar2(32767) := null;',
'begin',
'if wwv_flow_collection.collection_exists(p_collection_name => ''COPY_PAGE_LOV'') and',
'   wwv_flow_collection.collection_member_count(p_collection_name => ''COPY_PAGE_LOV'') > 0',
'then',
'  q:=q||''select wwv_flow_item.hidden(3,c003)||wwv_flow_item.display_and_save(4,c004) old_lov_name, '';  ',
'  q:=q||''wwv_flow_item.display_and_save(5,c005) lov_type, '';     ',
'  q:=q||''wwv_flow_item.select_list_from_lov_xl(1,c001,''''COPY_SC_OPTION'''',''''onchange="f_CopyOption(this,''''''''id2_''''||rownum||'''''''''''')"'''',''''NO'''',null,null,''''id''''||1||''''_''''||rownum,wwv_flow_lang.system_message(''''F4000.P623.COPY_OPTION'''',c004),''''NO'''') copy'
||'_option, '';  ',
'  q:=q||''wwv_flow_item.select_list_from_lov_xl(2,c002,''''NAMED_LOV_RETURNING_ID'''',null,''''YES'''',''''0'''',wwv_flow_lang.system_message(''''COPY_PAGE.SELECT_NAMED_LOV''''),''''id''''||2||''''_''''||rownum,wwv_flow_lang.system_message(''''F4000.P623.EXISTING_LOV'''',c004),'''
||'''NO'''') new_lov '';',
'  q:=q||''from htmldb_collections '';',
'  q:=q||''where collection_name = ''''COPY_PAGE_LOV'''''';    ',
'else    ',
'  q:=q||''select wwv_flow_item.hidden(3,l.lov_id)||wwv_flow_item.display_and_save(4,wwv_flow_escape.html(l.lov_name)) old_lov_name, '';  ',
'  q:=q||''wwv_flow_item.display_and_save(5,l.lov_type) lov_type, '';  ',
'  q:=q||''wwv_flow_item.select_list_from_lov_xl(1,''''NO'''',''''COPY_SC_OPTION'''',''''onchange="f_CopyOption(this,''''''''id2_''''||rownum||'''''''''''')"'''',''''NO'''',null,null,''''id''''||1||''''_''''||rownum,wwv_flow_lang.system_message(''''F4000.P623.COPY_OPTION'''',wwv_flow_escape.'
||'html(l.lov_name)),''''NO'''') copy_option, '';  ',
'  q:=q||''wwv_flow_item.select_list_from_lov_xl(2,''''0'''',''''NAMED_LOV_RETURNING_ID'''',null,''''YES'''',''''0'''',wwv_flow_lang.system_message(''''COPY_PAGE.SELECT_NAMED_LOV''''),''''id''''||2||''''_''''||rownum,wwv_flow_lang.system_message(''''F4000.P623.EXISTING_LOV'''',wwv_fl'
||'ow_escape.html(l.lov_name)),''''NO'''') new_lov ''; ',
'  q:=q||''from ( '';',
'  q:=q||''select distinct i.named_lov lov_name, '';',
'  q:=q||''   l.id lov_id, '';',
'  q:=q||''   decode(substr(l.LOV_QUERY,1,1), '';',
'  q:=q||''          ''''.'''', '';',
'  q:=q||''          wwv_flow_lang.system_message(''''F4000.STATIC''''), '';',
'  q:=q||''          wwv_flow_lang.system_message(''''F4000.DYNAMIC'''')) lov_type '';',
'  q:=q||''from wwv_flow_step_items i, wwv_flow_page_plugs r, wwv_flow_lists_of_values$ l '';',
'  q:=q||''where i.flow_id = :P621_COPY_FROM_FLOW_ID and '';',
'  q:=q||''i.flow_step_id = :P621_COPY_FROM_PAGE_ID and '';',
'  q:=q||''r.page_id = i.flow_step_id and '';',
'  q:=q||''r.flow_id = i.flow_id and '';',
'  q:=q||''i.item_plug_id = r.id and '';',
'  q:=q||''i.named_lov = l.lov_name and '';',
'  q:=q||''i.flow_id = l.flow_id and '';',
'  q:=q||''i.named_lov is not null ''; ',
'  q:=q||''union '';',
'  q:=q||''select distinct l.lov_name lov_name, '';',
'  q:=q||''       l.id lov_id, '';',
'  q:=q||''   decode(substr(l.LOV_QUERY,1,1), '';',
'  q:=q||''          ''''.'''', '';',
'  q:=q||''   wwv_flow_lang.system_message(''''F4000.STATIC''''), '';',
'  q:=q||''   wwv_flow_lang.system_message(''''F4000.DYNAMIC'''')) lov_type '';',
'  q:=q||''from wwv_flow_region_report_column c, wwv_flow_page_plugs r, wwv_flow_lists_of_values$ l '';',
'  q:=q||''where c.flow_id = :P621_COPY_FROM_FLOW_ID and '';',
'  q:=q||''r.page_id = :P621_COPY_FROM_PAGE_ID and '';',
'  q:=q||''c.region_id = r.id and '';',
'  q:=q||''c.named_lov = l.id and '';',
'  q:=q||''r.flow_id = c.flow_id '';',
'  q:=q||''union '';',
'  q:=q||''select distinct l.lov_name lov_name, '';',
'  q:=q||''       l.id lov_id, '';',
'  q:=q||''   decode(substr(l.LOV_QUERY,1,1), '';',
'  q:=q||''          ''''.'''', '';',
'  q:=q||''   wwv_flow_lang.system_message(''''F4000.STATIC''''), '';',
'  q:=q||''   wwv_flow_lang.system_message(''''F4000.DYNAMIC'''')) lov_type '';',
'  q:=q||''from wwv_flow_region_columns c, wwv_flow_page_plugs r, wwv_flow_lists_of_values$ l '';',
'  q:=q||''where c.flow_id = :P621_COPY_FROM_FLOW_ID and '';',
'  q:=q||''r.page_id = :P621_COPY_FROM_PAGE_ID and '';',
'  q:=q||''c.region_id = r.id and '';',
'  q:=q||''( c.lov_id = l.id or c.filter_lov_id = l.id ) and '';',
'  q:=q||''r.flow_id = c.flow_id '';',
'  q:=q||''union '';',
'  q:=q||''select distinct k.lov_name lov_name,  '';',
'  q:=q||''       k.id lov_id, '';  ',
'  q:=q||''   decode(substr(k.LOV_QUERY,1,1), '';',
'  q:=q||''          ''''.'''', '';',
'  q:=q||''   wwv_flow_lang.system_message(''''F4000.STATIC''''), '';',
'  q:=q||''   wwv_flow_lang.system_message(''''F4000.DYNAMIC'''')) lov_type '';',
'  q:=q||''      from wwv_flow_worksheet_columns m, wwv_flow_lists_of_values$ k, WWV_FLOW_WORKSHEETS n '';',
'  q:=q||''where m.flow_id = :P621_COPY_FROM_FLOW_ID and '';',
'  q:=q||''      n.page_id = :P621_COPY_FROM_PAGE_ID and '';',
'  q:=q||''      m.rpt_named_lov = k.id and '';',
'  q:=q||''      m.worksheet_id = n.id and '';',
'  q:=q||''      n.flow_id = m.flow_id ) l'';',
'end if;  ',
'',
'return q;',
'end;'));

update wwv_flow_page_plugs
   set plug_source = l_code
where flow_id between 4000 and 4009
  and page_id >= 623
  and page_id < 623 + 1
  and id >= 201008603702857054 
  and id < 201008603702857054 + 1
  and security_group_id = 10;
end;
/

commit
/
