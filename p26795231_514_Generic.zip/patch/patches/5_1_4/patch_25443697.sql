set define '^' verify off
prompt ...patch_25443697.sql

Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    jkallman    02/24/2017 - Created patch file for bug 25443697
Rem    jkallman    03/02/2017 - Added support for Azerbaijani (Bug 25443697)
Rem    jkallman    06/22/2017 - Execute insert into wwv_flow_list_of_values_data only if executing against a full development environment

begin

    update wwv_flow_languages set translated_lang_name = unistr('\0641\0627\0631\0633\06CC') where lang_id = 'fa';
    update wwv_flow_languages set translated_lang_name = unistr('Bahasa Indonesia') where lang_id = 'id';
    update wwv_flow_languages set translated_lang_name = unistr('\00EDslenska') where lang_id = 'is';
    update wwv_flow_languages set translated_lang_name = unistr('\041C\0430\043A\0435\0434\043E\043D\0441\043A\0438') where lang_id = 'mk';      


    begin
        insert into wwv_flow_languages(id,lang_id,lang_id_upper,lang_name,nls_language,nls_territory,nls_sort,nls_windows_charset,translated_lang_name,dl_format,ds_format)
        values (137, 'az', null, 'Azerbaijani', 'AZERBAIJANI', 'AZERBAIJAN', null, 'AL32UTF8',unistr('Az\0259rbaycan'),unistr('fmdd Month yyyy, Day'),unistr('DD.MM.RRRR'));

    exception
        when dup_val_on_index then null;
    end;        


    for c1 in (select null from wwv_flows where id = 4000) loop -- only execute if this is a full development environment    

        /* I18N_LANGUAGES_LOCALES 4000 */ 
        begin
            insert into wwv_flow_list_of_values_data( id, lov_id, flow_id, lov_disp_sequence, lov_disp_value, lov_return_value, security_group_id )
            values( 62331376945397671, 107899321117195063, 4000, 10, 'Azerbaijani (az)', 'az', 10 );
        exception
            when dup_val_on_index then null;        
        end;

        /* I18N_TERRITORIES 4000 */ 
        begin
            insert into wwv_flow_list_of_values_data( id, lov_id, flow_id, lov_disp_sequence, lov_disp_value, lov_return_value, security_group_id )
            values( 62332080749407778, 634612723768159258, 4000, 10, 'Azerbaijan', 'AZERBAIJAN', 10 );
        exception
            when dup_val_on_index then null;        
        end;

        /* I18N_LANGUAGES_LOCALES 4050 */ 
        begin
            insert into wwv_flow_list_of_values_data( id, lov_id, flow_id, lov_disp_sequence, lov_disp_value, lov_return_value, security_group_id )
            values( 62591351690441198, 348975927644434787, 4050, 10, 'Azerbaijani (az)', 'az', 10 );
        exception
            when dup_val_on_index then null;        
        end;

        /* I18N_TERRITORIES 4050 */ 
        begin
            insert into wwv_flow_list_of_values_data( id, lov_id, flow_id, lov_disp_sequence, lov_disp_value, lov_return_value, security_group_id )
            values( 62829689894442518, 788953931940024140, 4050, 10, 'Azerbaijan', 'AZERBAIJAN', 10 );
        exception
            when dup_val_on_index then null;        
        end;    

        /* I18N_LANGUAGES_LOCALES 4400 */ 
        begin
            insert into wwv_flow_list_of_values_data( id, lov_id, flow_id, lov_disp_sequence, lov_disp_value, lov_return_value, security_group_id )
            values( 62495706068441128, 19539723892904486, 4400, 10, 'Azerbaijani (az)', 'az', 10 );
        exception
            when dup_val_on_index then null;        
        end;

        /* I18N_LANGUAGES_LOCALES 4900 */ 
        begin
            insert into wwv_flow_list_of_values_data( id, lov_id, flow_id, lov_disp_sequence, lov_disp_value, lov_return_value, security_group_id )
            values( 62686984165441270, 502587106305037128, 4900, 10, 'Azerbaijani (az)', 'az', 10 );
        exception
            when dup_val_on_index then null;        
        end;

        /* I18N_TERRITORIES 4900 */ 
        begin
            insert into wwv_flow_list_of_values_data( id, lov_id, flow_id, lov_disp_sequence, lov_disp_value, lov_return_value, security_group_id )
            values( 62768512046442477, 634728210841234369, 4900, 10, 'Azerbaijan', 'AZERBAIJAN', 10 );
        exception
            when dup_val_on_index then null;        
        end;

    end loop;

    commit;
    
end;
/
