set define '^' verify off
set concat on
set concat .

Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      syspatch.sql
Rem
Rem    DESCRIPTION
Rem      Application Express patch
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     12/22/2016 - Created
Rem    vuvarov     03/29/2017 - Updated for APEX 5.1.2
Rem    cneumuel    04/20/2017 - Added validate_apex.sql (bug #21382758)
Rem    cneumuel    06/07/2017 - Added wwv_dbms_sql.plb (bug #26223808)
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4

define APPUN        = 'APEX_050100'
define PREFIX       = '^1'
define INSTALL_TYPE = '^2'

@^PREFIX.patches/5_1_4/prereq.sql

declare
    invalid_alter_priv exception;
    pragma exception_init(invalid_alter_priv,-02248);
begin
    execute immediate 'alter session set "_ORACLE_SCRIPT"=true';
exception
    when invalid_alter_priv then
        null;
end;
/

alter session set current_schema = ^APPUN.;

--
-- Stop and disable all scheduler jobs owned by APEX user
--
begin
    sys.dbms_output.put_line( 'Stopping and disabling APEX jobs' );
    for c1 in (select owner, job_name
                 from sys.dba_scheduler_jobs
                where owner = '^APPUN.') loop
        begin
            sys.dbms_scheduler.stop_job( job_name => c1.owner || '.' || c1.job_name, force => TRUE );
        exception
            when others then
                if sqlcode <> -27366 then
                    raise;
                end if;
        end;
        sys.dbms_scheduler.disable( name => c1.owner || '.' || c1.job_name, force => TRUE );
    end loop;
    commit;
end;
/

exec sys.dbms_registry.loading('APEX','Oracle Application Express');

alter session set current_schema = SYS;

grant select on sys.dba_scheduler_jobs             to ^APPUN;

--
-- Any SYS specific files should go here
-- @^PREFIX.core/foo.sql
@^PREFIX.core/validate_apex.sql x x ^APPUN.
@^PREFIX.core/wwv_dbms_sql.plb
--

-------------------------------------------------------------------
-- patch files requiring SYS connect
-- @^PREFIX.patches/5_1_2/patch_123456.sql
-------------------------------------------------------------------

