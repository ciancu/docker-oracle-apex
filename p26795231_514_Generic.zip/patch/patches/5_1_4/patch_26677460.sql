set define '^' verify off
prompt ...patch_26677460.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_26677460.sql
--
-- DESCRIPTION
--   Change Password region on Edit Profile page (4350:3) always visible, region
--   title depends on auth scheme.
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  09/11/2017 - Created
--
--------------------------------------------------------------------------------

update wwv_flow_page_plugs
   set plug_name                   = '<a name="pwd"></a>&F4350_PASSWORD_REGION_TITLE.',
       plug_display_condition_type = null,
       plug_display_when_condition = null
 where security_group_id = 10
   and id between 1142730993807397049 and 1142730993807397049.9999
/
