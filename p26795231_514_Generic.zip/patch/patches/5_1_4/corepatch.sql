set define '^' verify off
set concat on
set concat .

Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      corepatch.sql
Rem
Rem    DESCRIPTION
Rem      Application Express patch
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     12/22/2016 - Created
Rem    pawolf      01/11/2017 - Added gen_api_pkg.plb
Rem    arayner     01/11/2017 - Added wwv_flow_ws_dialog.plb
Rem    cbcho       01/13/2017 - Added wwv_flow_pkg_app_install.plb
Rem    hfarrell    01/16/2017 - Added wwv_flow_upgrade.plb (bug #25387702)
Rem    cczarski    01/16/2017 - Added wwv_flow_instance_rest_admin.plb (bugs #25315991, #25399059)
Rem    pawolf      01/17/2017 - Added wwv_flow_plugin.plb (bug #25403748)
Rem    hfarrell    01/16/2017 - Added wwv_flow_dynamic_action_native.plb (bug #25348067)
Rem    cneumuel    01/19/2017 - Added wwv_flow_response.plb (bug #25422368)
Rem    cbcho       01/20/2017 - Added wwv_flow_worksheet_api.plb (bug #25423099)
Rem    hfarrell    01/23/2017 - Moved wizapi.plb from corepatch.sql (bug 25421700)
Rem    cneumuel    01/24/2017 - Added api.plb (bug #25430809)
Rem    pawolf      01/25/2017 - Added wwv_flow_instance_admin.plb
Rem    cneumuel    01/26/2017 - Added wwv_flow_branch.plb (bug #25373158)
Rem    hfarrell    01/27/2017 - Added wwv_flow_native_item.plb (bug #23507365)
Rem    cneumuel    01/27/2017 - Added wwv_flow_json.plb (bug #25298133)
Rem                           - Added wwv_flow_web_services.plb (bug #25202042)
Rem                           - Added wwv_flow_security.plb (bug #25435728)
Rem    hfarrell    01/27/2017 - Added wwv_flow_interactive_grid.plb (bug #25442686)
Rem    hfarrell    02/02/2017 - Added wwv_flow_authentication.plb (bug #25473808)
Rem    cneumuel    02/02/2017 - Added flow.plb (bug #25473808)
Rem    vuvarov     02/02/2017 - Added patch_25489827.sql (bug 25489827)
Rem    cneumuel    02/03/2017 - Added wwv_flow_session_ras.plb (bug #25225356)
Rem    cneumuel    02/03/2017 - Added wwv_flow_mail.plb (bug #25311325)
Rem    cneumuel    02/06/2017 - Added patch_25311325.sql (bug #25311325)
Rem    cneumuel    02/07/2017 - Added wwv_flow_session.plb (bug #25510163)
Rem    cneumuel    02/07/2017 - Added custom_auth_std.plb (bug #25511529)
Rem    msewtz      02/07/2017 - Added wwv_flow_region_native.plb (bug #25206891)
Rem    hfarrell    02/08/2017 - Moved patch_25311325.sql to ddlpatch.sql - dependencies on wwv_flow_mail.plb (bug #25311325)
Rem    cbcho       02/08/2017 - Added wwv_flow_ws_webpage.plb (bug #25489933)
Rem    cczarski    02/17/2017 - Added wwv_flow_css_calendar (bug #25538561)
Rem    cneumuel    02/23/2017 - Added flowu.plb (bug #25595984)
Rem    jkallman    02/24/2017 - Added patch_25443697.sql (Bug 25443697)
Rem    cneumuel    03/02/2017 - Set APEX_PATCH_STATUS=APPLIED at the end
Rem    jkallman    03/02/2017 - Added wwv_purge.plb (Bug 25291399)
Rem    hfarrell    03/07/2017 - Added wwv_flow_worksheet.plb (bug #25234978)
Rem    cneumuel    03/10/2017 - Added wwv_flow_error.plb (bug #25703029)
Rem    jkallman    03/10/2017 - Added flowl.plb, wwv_flow_translation_util_api.plb (Bug 25706037)
Rem    vuvarov     03/29/2017 - Updated for APEX 5.1.2
Rem    cczarski    04/03/2017 - Added wwv_flow_data_upload.plb (Bug #25771685)
Rem    cczarski    04/07/2017 - Added form.plb (Bug #25855970)
Rem    cneumuel    04/13/2017 - Added wwv_flow_t_clob_writer.plb (bug #25853436)
Rem    cneumuel    04/21/2017 - Added wwv_flow_cgi.plb, wwv_flow_debug.plb (bug #25851470)
Rem    cneumuel    04/21/2017 - Added wwv_flow_calender.plb (bug #25931034)
Rem    cbcho       04/21/2017 - Added wwv_flow_worksheet_standard.plb (bug #21690069)
Rem    cczarski    04/26/2017 - Added wwv_flow_process.plb (bug #25718359)
Rem    cneumuel    04/27/2017 - Added flowc.plb (bug #21690069)
Rem    hfarrell    05/03/2017 - Added imp_parser.plb (bug #25992450)
Rem    cneumuel    05/08/2017 - Added wwv_flow_webservices_api.plb (bug #26022776)
Rem                           - Added wwv_flow_session_state.plb (bug #26004946)
Rem    hfarrell    05/10/2017 - Added wwv_flow_jet_chart.plb (bug #26030893)
Rem    cczarski    05/12/2017 - Added wwv_flow_dynamic_exec.plb (bug #26048323)
Rem    hfarrell    05/15/2017 - Added wwv_flow_flash_chart5.plb (bug #25119626)
Rem    hfarrell    05/16/2017 - Added collection.plb (bug #26078193)
Rem    cneumuel    05/23/2017 - Added wwv_flow_fnd_user_int.plb (bug #25729755)
Rem                           - Added provision.plb (bug #25790200)
Rem    pawolf      05/24/2017 - Added wwv_flow_plugin_util.plb (bug #25931766)
Rem    cneumuel    05/31/2017 - Added patch_25966414.sql
Rem    cneumuel    06/07/2017 - Added patch_26223789.sql
Rem    cneumuel    06/07/2017 - Added wwv_flow_crypto.plb, wwv_flow_fnd_developer_api.plb (bug #25790200)
Rem    cneumuel    06/07/2017 - Reset package state after compile and patches (bug #26225035)
Rem    cneumuel    06/08/2017 - Recompile wwv_flow_t_writer (bug #26200919)
Rem    hfarrell    06/09/2017 - Reposition call to sys.validate_apex and resolve reference to WWV_DBMS_SQL (bug #26246213)
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    cneumuel    06/27/2017 - Added sw_api.plb (bug #25853436)
Rem    hfarrell    06/29/2017 - Added wwv_flow_ppr_util.plb (bug #26369817)
Rem    cczarski    07/18/2017 - Added patch_26255035.sql (bug #26255035)
Rem    cneumuel    07/19/2017 - Added wwv_flow_maint.plb (bug #26416174)
Rem    pawolf      07/20/2017 - Added wwv_flow_file_mgr.plb (bug #26369194)
Rem    cneumuel    07/25/2017 - Added wwv_flow_cloud_idm.plb (bug #25791440)
Rem    pawolf      08/17/2017 - Added wwv_flow_data_export.plb (bug #26326589)
Rem    hfarrell    08/18/2017 - Added wwv_flow_file_api.plb (Jason's changes)
Rem    cneumuel    08/29/2017 - Added wwv_flow_authentication_native.plb (bug #26717149)
Rem    hfarrell    09/04/2017 - Added wwv_flow_listener.plb (bug #26744139)
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4
Rem    pawolf      09/27/2017 - Added wwv_flow_css.plb and wwv_flow_javascript.plb (bug #26860634)
Rem    cbcho       09/29/2017 - Added patch_21690069.sql (bug #21690069)
Rem    cbcho       09/29/2017 - Added wwv_flow_worksheet_util.plb (bug #21690069)
Rem    cneumuel    10/10/2017 - Added {wwv_flow_export_api,wwv_flow_export_int}.plb (feature #2224)
Rem    cneumuel    10/18/2017 - Added prov.plb (bug #26757293)
Rem    cneumuel    10/25/2017 - Added flow_log.plb, wwv_flow_worksheet_ajax.plb (bug #26987712)
Rem    hfarrell    11/01/2017 - Added wwv_flow_escape.plb
Rem    cneumuel    11/07/2017 - Added wwv_flow_char_reader.plb

define APPUN        = 'APEX_050100'
define PREFIX       = '^1'
define INSTALL_TYPE = '^2'

@^PREFIX.patches/5_1_4/prereq.sql

declare
    invalid_alter_priv exception;
    pragma exception_init(invalid_alter_priv,-02248);
begin
    execute immediate 'alter session set "_ORACLE_SCRIPT"=true';
exception
    when invalid_alter_priv then
        null;
end;
/

alter session set current_schema = ^APPUN.;


set define '^'
alter session set current_schema = ^APPUN.;


-------------------------------------------------------------------
-- package specs are in deppatch.sql
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Compilation of package bodies
-------------------------------------------------------------------
@^PREFIX.core/gen_api_pkg.plb
@^PREFIX.core/wwv_flow_ws_dialog.plb
@^PREFIX.core/wwv_flow_pkg_app_install.plb
@^PREFIX.core/wwv_flow_upgrade.plb
@^PREFIX.core/wwv_flow_instance_rest_admin.plb
@^PREFIX.core/wwv_flow_plugin.plb
@^PREFIX.core/wwv_flow_dynamic_action_native.plb
@^PREFIX.core/wwv_flow_response.plb
@^PREFIX.core/wwv_flow_worksheet.plb
@^PREFIX.core/wwv_flow_worksheet_api.plb
@^PREFIX.core/wizapi.plb
@^PREFIX.core/api.plb
@^PREFIX.core/wwv_flow_instance_admin.plb
@^PREFIX.core/wwv_flow_branch.plb
@^PREFIX.core/wwv_flow_char_reader.plb
@^PREFIX.core/wwv_flow_json.plb
@^PREFIX.core/wwv_flow_native_item.plb
@^PREFIX.core/wwv_flow_web_services.plb
@^PREFIX.core/wwv_flow_security.plb
@^PREFIX.core/wwv_flow_interactive_grid.plb
@^PREFIX.core/wwv_flow_authentication.plb
@^PREFIX.core/flow.plb
@^PREFIX.core/wwv_flow_session_ras.plb
@^PREFIX.core/wwv_flow_mail.plb
@^PREFIX.core/wwv_flow_session.plb
@^PREFIX.core/custom_auth_std.plb
@^PREFIX.core/wwv_flow_region_native.plb
@^PREFIX.core/wwv_flow_ws_webpage.plb
@^PREFIX.core/wwv_flow_css_calendar.plb
@^PREFIX.core/flowu.plb
@^PREFIX.core/wwv_purge.plb
@^PREFIX.core/flowl.plb
@^PREFIX.core/wwv_flow_translation_util_api.plb
@^PREFIX.core/wwv_flow_error.plb
@^PREFIX.core/wwv_flow_escape.plb
@^PREFIX.core/wwv_flow_data_upload.plb
@^PREFIX.core/form.plb
@^PREFIX.core/wwv_flow_t_clob_writer.plb
@^PREFIX.core/wwv_flow_cgi.plb
@^PREFIX.core/wwv_flow_debug.plb
@^PREFIX.core/wwv_flow_calendar.plb
@^PREFIX.core/wwv_flow_worksheet_standard.plb
@^PREFIX.core/wwv_flow_process.plb
@^PREFIX.core/flowc.plb
@^PREFIX.core/imp_parser.plb
@^PREFIX.core/wwv_flow_webservices_api.plb
@^PREFIX.core/wwv_flow_session_state.plb
@^PREFIX.core/wwv_flow_jet_chart.plb
@^PREFIX.core/wwv_flow_dynamic_exec.plb
@^PREFIX.core/wwv_flow_flash_chart5.plb
@^PREFIX.core/collection.plb
@^PREFIX.core/wwv_flow_fnd_user_int.plb
@^PREFIX.core/provision.plb
@^PREFIX.core/wwv_flow_plugin_util.plb
@^PREFIX.core/wwv_flow_crypto.plb
@^PREFIX.core/wwv_flow_fnd_developer_api.plb
@^PREFIX.core/sw_api.plb
@^PREFIX.core/wwv_flow_ppr_util.plb
@^PREFIX.core/wwv_flow_maint.plb
@^PREFIX.core/wwv_flow_file_mgr.plb
@^PREFIX.core/wwv_flow_cloud_idm.plb
@^PREFIX.core/wwv_flow_data_export.plb
@^PREFIX.core/wwv_flow_file_api.plb
@^PREFIX.core/wwv_flow_authentication_native.plb
@^PREFIX.core/wwv_flow_listener.plb
@^PREFIX.core/wwv_flow_css.plb
@^PREFIX.core/wwv_flow_javascript.plb
@^PREFIX.core/wwv_flow_worksheet_util.plb
@^PREFIX.core/wwv_flow_export_api.plb
@^PREFIX.core/wwv_flow_export_int.plb
@^PREFIX.core/prov.plb
@^PREFIX.core/flow_log.plb
@^PREFIX.core/wwv_flow_worksheet_ajax.plb

set define '^'
begin
    wwv_flow_security.g_security_group_id := 10;
end;
/

-------------------------------------------------------------------
-- Compilation of development package specifications and bodies
-------------------------------------------------------------------
set define '^'
column thescript new_val script
set termout off
select decode(count(*),0,'null1.sql','devpatch.sql') thescript from wwv_flows where id = 4000;
set termout on
@^PREFIX.patches/5_1_4/^script ^INSTALL_TYPE


set define '^' verify off
begin
    if '^INSTALL_TYPE' = 'MANUAL' then
        sys.dbms_utility.compile_schema('^APPUN.', false);
        sys.dbms_utility.compile_schema('PUBLIC', false);
        sys.dbms_utility.compile_schema('FLOWS_FILES', false);
    end if;
end;
/
alter type wwv_flow_t_writer compile body;
exec sys.dbms_session.modify_package_state(sys.dbms_session.reinitialize)

-------------------------------------------------------------------
-- patch files
-- @^PREFIX.patches/5_1_4/patch_123456.sql
-------------------------------------------------------------------
@^PREFIX.patches/5_1_4/patch_25489827.sql
@^PREFIX.patches/5_1_4/patch_25443697.sql
@^PREFIX.patches/5_1_4/patch_25966414.sql
@^PREFIX.patches/5_1_4/patch_26223789.sql
@^PREFIX.patches/5_1_4/patch_26255035.sql
@^PREFIX.patches/5_1_4/patch_21690069.sql


-- commit after dml changes to metadata
commit;
exec sys.dbms_session.modify_package_state(sys.dbms_session.reinitialize)

-------------------------------------------------------------------
-- Load internal themes
-------------------------------------------------------------------
set define '^'
@^PREFIX.core/themes/apex_install_theme_42.sql

-------------------------------------------------------------------
-- Load Property Editor metadata
-------------------------------------------------------------------
set define '^'
@^PREFIX.core/apex_install_pe_data.sql NO

-------------------------------------------------------------------
prompt ...Adjust internal application version
-------------------------------------------------------------------
set define '^'

column flow_version new_val VERSION
set termout off
select wwv_flows_release flow_version from sys.dual where rownum = 1;
set termout on

update wwv_flows
   set flow_version = '&PRODUCT_NAME. ' || '^VERSION.'
 where id between 4000 and 4999
/

update wwv_flows
   set flow_version = '&PRODUCT_NAME. '
 where id between 4550 and 4559
/

-------------------------------------------------------------------
prompt ...Clear page and region cache
-------------------------------------------------------------------
delete from wwv_flow_page_cache
/
commit
/


--
-- Enable all scheduler jobs owned by APEX user
--
begin
    sys.dbms_output.put_line( 'Enabling APEX jobs' );
    for c1 in (select owner, job_name
                 from sys.dba_scheduler_jobs
                where owner = '^APPUN.') loop
        sys.dbms_scheduler.enable( name => c1.owner || '.' || c1.job_name );
    end loop;
    commit;
end;
/

-- Set instance parameters to indicate this is a patched instance
begin
    wwv_flow_platform.set_preference (
        p_preference_name  => 'APEX_' || replace('^VERSION.', '.', '_') || '_PATCH',
        p_preference_value => to_char(sysdate,'YYYY-MM-DD_HH24-MI-SS') );
    wwv_flow_platform.set_preference (
        p_preference_name  => 'APEX_PATCH_STATUS',
        p_preference_value => 'APPLIED' );
    commit;
end;
/

exec sys.dbms_registry.loaded('APEX','^VERSION.');

alter session set current_schema = SYS;

begin
    for c1 in (
        select object_id
          from sys.all_objects
         where owner = 'SYS'
           and status = 'INVALID'
           and object_type = 'PACKAGE BODY'
           and object_name in ( 'HTMLDB_SYSTEM', 'WWV_DBMS_SQL_APEX_050100' )
    ) loop
        sys.dbms_utility.validate(c1.object_id);
    end loop;
end;
/

prompt ...Validating Application Express
exec sys.validate_apex;

declare
    invalid_alter_priv exception;
    pragma exception_init(invalid_alter_priv,-02248);
begin
    execute immediate 'alter session set "_ORACLE_SCRIPT"=false';
exception
    when invalid_alter_priv then
        null;
end;
/
