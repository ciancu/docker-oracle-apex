set define '^' verify off
prompt ...patch_22067754.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_22067754.sql
--
-- DESCRIPTION
--   Fix builder queries for metadata that do not use wwv_flow_%_dev views
--
--   LOVs: P5_TABLES_VIEWS, P257_TABLE_VIEWS
--   ITEM LOVs: P265_TABLE
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  03/31/2017 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- LOV P5_TABLES_VIEWS
--==============================================================================
update wwv_flow_lists_of_values$
   set lov_query = wwv_flow_string.join(wwv_flow_t_varchar2(
'if nvl(:P5_RELATED,''N'') = ''N'' then',
'return ''select object_name_esc, object_name',
'from wwv_flow_tables_views_dev',
'where owner = :P5_DETAIL_OWNER',
'order by 1'';',
'else',
'return ''select detail_table_name d, detail_table_name r',
'           from wwv_flow_detail_tables_dev',
'          where master_owner      = :P4_MASTER_OWNER',
'            and detail_owner      = :P5_DETAIL_OWNER',
'            and master_table_name = :P4_MASTER_TABLE',
'          order by 1'';',
'end if;'))
where security_group_id =       10
  and flow_id           between 4000 and 4009
  and lov_name          =       'P5_TABLES_VIEWS'
  and id                between 941404414700155 and 941404414700155.9999
/
--==============================================================================
-- LOV 4000:P257_TABLE_VIEWS
--==============================================================================
update wwv_flow_lists_of_values$
   set lov_query = wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    q varchar2(32767);',
'begin',
'    if nvl(:P257_SHOW_RELATED_TABLES,''N'') = ''N'' then',
'        q := ''select object_name_esc, object_name from wwv_flow_tables_views_dev where owner = :P257_DETAIL_OWNER order by 1'';',
'    else',
'        q := ''select detail_table_name d, detail_table_name r',
'                 from wwv_flow_detail_tables_dev',
'                where master_owner      = :P239_MASTER_OWNER',
'                  and detail_owner      = :P257_DETAIL_OWNER',
'                  and master_table_name = :P239_MASTER_TABLE',
'                order by 1'';',
'    end if;',
'    return q;',
'end;'))
where security_group_id =       10
  and flow_id           between 4000 and 4009
  and lov_name          =       'P257_TABLE_VIEWS'
  and id                between 536224160727617714 and 536224160727617714.9999
/
--==============================================================================
-- tickle items, so they get the lov query via the trigger
--==============================================================================
update wwv_flow_step_items
   set lov=lov
 where security_group_id =       10
   and flow_id           between 4000 and 4009
   and named_lov         in ('P5_TABLES_VIEWS', 'P257_TABLE_VIEWS')
/
--==============================================================================
-- Item 4000:P265_TABLE
--==============================================================================
update wwv_flow_step_items
   set lov = wwv_flow_string.join(wwv_flow_t_varchar2(
'select object_name_esc d,object_name v',
'  from wwv_flow_tables_views_dev',
' where owner = :p265_OWNER',
' order by 1' ))
where security_group_id = 10
  and flow_id between 4000 and 4009
  and name = 'P265_TABLE'
  and id between 269336356418506220 and 269336356418506220.9999
/

--==============================================================================
commit
/
