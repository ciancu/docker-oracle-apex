set define '^' verify off
prompt ...patch_25307229.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25307229.sql
--
--    DESCRIPTION
--      Amend region source query for 'Saved SQL' region on 4500:1203
--
--    MODIFIED   (MM/DD/YYYY)
--    arayner     10/01/2017 - Created
--
--------------------------------------------------------------------------------



declare
    l_code varchar2(32767);
begin
    l_code := wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ID,',
'       QUERY_OWNER,',
'       case query_type',
'         when ''W'' then wwv_flow_lang.system_message(''SC_VQ'')',
'         when ''R'' then wwv_flow_lang.system_message(''SC_SC'')',
'       end qType,',
'       title,',
'       sys.dbms_lob.substr(QB_SQL,120) as QB_SQL,',
'       DESCRIPTION,',
'       CREATED_BY,',
'       CREATED_ON,',
'       LAST_UPDATED_BY,',
'       LAST_UPDATED_ON,',
'       SECURITY_GROUP_ID,',
'       ''javascript:sc_postSavedSQL(''||',
'            wwv_flow_escape.js_literal(id)||',
'       '',''||wwv_flow_escape.js_literal(title)||',
'       '',''||wwv_flow_escape.js_literal(description)||',
'       '',''||wwv_flow_escape.js_literal(',
'                case query_type',
'                  when ''W'' then ''VQB''',
'                  when ''R'' then ''SC''',
'                end)||',
'       '',''||wwv_flow_escape.js_literal(query_owner)||',
'       '');'' link_url',
' from WWV_FLOW_QB_SAVED_QUERY',
'where security_group_id = :FLOW_SECURITY_GROUP_ID',
'  and (:P1203_FIND is null',
'       or instr(upper(title),upper(:P1203_FIND)) > 0 ',
'       or instr(upper(QB_SQL),upper(:P1203_FIND)) > 0 )',
'  and (created_by = case when :P1203_SHOW = ''0'' then created_by else :P1203_SHOW end) ',
'  and (created_by = :APP_USER',
'      or exists ( select 1',
'                    from wwv_flow_developers',
'                   where security_group_id = :flow_security_group_id',
'                     and userid = :APP_USER',
'                     and instr(developer_role||'':'',''ADMIN:'') > 0',
'                   union',
'                  select 1',
'                    from wwv_flow_fnd_user',
'                   where security_group_id = :FLOW_SECURITY_GROUP_ID',
'                     and user_name = :APP_USER',
'                     and attribute_01 in (''ORACLE_ADMIN'',''SCHOOL_ADMIN'',''TEACHER'')))',
'order by LAST_UPDATED_ON desc'));
--
    update wwv_flow_page_plugs
       set plug_source = l_code
     where flow_id              between 4500 and 4509
       and id                   >= 6415019707620645 
       and id                   < 6415019707620645 + 1
       and security_group_id    = 10;
end;
/
commit
/
