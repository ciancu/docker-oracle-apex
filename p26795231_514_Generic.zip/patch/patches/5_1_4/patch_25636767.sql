set define '^' verify off
prompt ...patch_25636767.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25636767.sql
--
--    DESCRIPTION
--      Remove max length from json attribute of theme style on page 4000:177
--
--    MODIFIED   (MM/DD/YYYY)
--    xhu         05/11/2017 - Created
--
--------------------------------------------------------------------------------

-- P177_THEME_ROLLER_CONFIG
begin
    update wwv_flow_step_items
       set cmaxlength        =  null           
     where flow_id           between 4000 and 4009
       and flow_step_id      >= 177
       and flow_step_id      <  177 + 1
       and id                >= 1791909606437372803
       and id                <  1791909606437372803 + 1
       and security_group_id = 10;
end;
/
commit
/
