set define '^' verify off
prompt ...patch_25311325.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_25311325.sql
--
-- DESCRIPTION
--   Add column wwv_flow_mail_log.mail_message_id
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  02/06/2017 - Created
--
--------------------------------------------------------------------------------

declare
    e_column_exists exception;
    pragma exception_init(e_column_exists, -1430);
begin
    execute immediate 'alter table wwv_flow_mail_log add mail_message_id varchar2(4000)';
exception when e_column_exists then null;
end;
/
