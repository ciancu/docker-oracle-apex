set define '^' verify off
prompt ...patch_25430809.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_25430809.sql
--
-- DESCRIPTION
--   On app export page 4000:4900, set default of "Export with Original IDs" to
--   "No".
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  01/25/2017 - Created
--
--------------------------------------------------------------------------------

update wwv_flow_step_items
   set item_default = 'N'
 where security_group_id =       10
   and flow_id           between 4000 and 4009
   and flow_step_id      >= 4900
   and flow_step_id      < 4900 + 1
   and id                >= 28916903130872699 
   and id                < 28916903130872699 + 1
   and security_group_id = 10
/
commit
/
