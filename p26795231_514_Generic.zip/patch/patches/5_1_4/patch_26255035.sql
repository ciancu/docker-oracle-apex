set define '^' verify off
prompt ...patch_26255035.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_26255035.sql
--
--    DESCRIPTION
--      Rectify APEX.IG.MAILADRESSES_COMMASEP text message in 4411
--
--    MODIFIED   (MM/DD/YYYY)
--    hfarrell    07/18/2017 - Created
--
--------------------------------------------------------------------------------


begin
    update wwv_flow_messages$
       set message_text = 'Separate multiple addresses with commas'
     where flow_id           = 4411
       and security_group_id = 10
       and id                = 1107296133634884322;

    commit;       
end;
/
