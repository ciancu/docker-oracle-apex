set define '^' verify off
prompt ...patch_25966414.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_25966414.sql
--
-- DESCRIPTION
--   Grant select, not read on wwv_flow_collections to public
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  05/31/2017 - Created
--
--------------------------------------------------------------------------------

begin
    for i in ( select null
                 from sys.dba_tab_privs
                where grantee    = 'PUBLIC'
                  and grantor    = 'APEX_050100'
                  and table_name = 'WWV_FLOW_COLLECTIONS'
                  and privilege  = 'READ' )
    loop
        execute immediate 'revoke read on APEX_050100.WWV_FLOW_COLLECTIONS from public';
        execute immediate 'grant select on APEX_050100.WWV_FLOW_COLLECTIONS to public';
    end loop;
end;
/
