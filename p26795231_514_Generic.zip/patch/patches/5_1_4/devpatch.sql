set define '^' verify off
set concat on
set concat .
prompt ...devpatch.sql

Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      devpatch.sql
Rem
Rem    DESCRIPTION
Rem      Application Express patch for a full development installation.
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     12/22/2016 - Created
Rem    arayner     01/10/2017 - Added patch_25307229.sql
Rem    msewtz      01/10/2017 - Added wwv_flow_team_api.sql, wwv_flow_team_api.plb and wwv_flow_team_gen_api.plb (bug 25374827)
Rem    hfarrell    01/11/2017 - Added patch_25216194.sql
Rem    cczarski    01/13/2017 - Added patch_25227883.sql
Rem    hfarrell    01/13/2017 - Added patch_25381119.sql, wwv_flow_create_model_app.plb, wwv_flow_model_api.plb (bug 25381119)
Rem    cbcho       01/13/2017 - Added patch_25378653.sql
Rem    cbcho       01/13/2017 - Added patch_25387853.sql
Rem    msewtz      01/17/2017 - Added copy_metadata.plb (bug 25409901)
Rem    hfarrell    01/19/2017 - Added layout.plb (bug 25181666)
Rem    cczarski    01/20/2017 - Added wizapi.plb (bug 25421700)
Rem    hfarrell    01/20/2017 - Added patch_25427480.sql
Rem    hfarrell    01/23/2017 - Moved wizapi.plb to corepatch.sql
Rem    cneumuel    01/25/2017 - Added patch_25430809.sql
Rem    hfarrell    02/01/2017 - Added wwv_flow_upgrade_app.plb (bug 25480899)
Rem    cneumuel    02/01/2017 - Added apex_mig_projects_update.* and apex_ui_default_update.* (bug #25482334)
Rem    msewtz      02/07/2017 - Added patch_25407597.sql
Rem    arayner     02/08/2017 - Added wwv_flow_property_dev.plb (bug 24906541)
Rem    cczarski    02/17/2017 - Added wwv_flow_dataload_xml.plb (bug 25573512)
Rem    hfarrell    03/01/2017 - Added patch_24410383.sql
Rem    vuvarov     03/29/2017 - Updated for APEX 5.1.2
Rem    cneumuel    03/31/2017 - Added patch_22067754.sql
Rem    hfarrell    04/05/2017 - Added dev_views.sql (bug 22067754)
Rem    cneumuel    05/08/2017 - Added wwv_flow_authentication_dev.plb (bug #25940559)
Rem    xhu         05/11/2017 - Added patch_25636767.sql
Rem    cneumuel    05/11/2017 - Added patch_25940678.sql
Rem    cneumuel    06/07/2017 - Reset package state after compile (bug #26225035)
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    cneumuel    06/27/2017 - Added wwv_flow_cloud_db_services.plb (bug #25790200)
Rem    cbcho       06/27/2017 - Added wwv_lov_used_on_pages.sql (bug #26352078)
Rem    cbcho       06/29/2017 - Added wwv_flow_copy_page.plb (bug #26352078)
Rem    cbcho       06/29/2017 - Added patch_26352078_dev.sql (bug #26352078)
Rem    cbcho       08/04/2017 - Replaced patch_26352078_dev.sql call to new file patch_26352078.sql (bug #26352078)
Rem    msewtz      08/04/2017 - Added patch_26572627.sql (bug #26572627)
Rem    msewtz      09/01/2017 - Removed patch_26572627.sql (bug #26572627)
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4
Rem    cbcho       09/27/2017 - Added patch_26802765.sql (bug #26802765)
Rem    cneumuel    10/18/2017 - Added patch_26677460.sql (bug #26677460)
Rem    cneumuel    10/20/2017 - Added wwv_flow_ui_default_update_int.* (bug #26840384)

define APPUN        = 'APEX_050100'
define INSTALL_TYPE = '^1'

alter session set current_schema = ^APPUN.;

--
-- specs
-- @^PREFIX.core/foo.sql
--
@^PREFIX.core/wwv_flow_team_api.sql
@^PREFIX.core/apex_mig_projects_update.sql
@^PREFIX.core/apex_ui_default_update.sql
@^PREFIX.core/wwv_flow_ui_default_update_int.sql

--
-- views
-- @^PREFIX.core/foo.sql
--
@^PREFIX.core/dev_views.sql

--
-- bodies
-- @^PREFIX.core/foo.plb
--
@^PREFIX.core/wwv_flow_team_gen_api.plb
@^PREFIX.core/wwv_flow_team_api.plb
@^PREFIX.core/wwv_flow_create_model_app.plb
@^PREFIX.core/wwv_flow_model_api.plb
@^PREFIX.core/copy_metadata.plb
@^PREFIX.core/layout.plb
@^PREFIX.core/wwv_flow_upgrade_app.plb
@^PREFIX.core/apex_mig_projects_update.plb
@^PREFIX.core/apex_ui_default_update.plb
@^PREFIX.core/wwv_flow_property_dev.plb
@^PREFIX.core/wwv_flow_dataload_xml.plb
@^PREFIX.core/wwv_flow_authentication_dev.plb
@^PREFIX.core/wwv_flow_cloud_db_services.plb
@^PREFIX.core/wwv_lov_used_on_pages.sql
@^PREFIX.core/wwv_flow_copy_page.plb
@^PREFIX.core/wwv_flow_ui_default_update_int.plb


--
-- grants
--


--
-- public synonyms
--


begin
    if '^INSTALL_TYPE' = 'MANUAL' then
        sys.dbms_utility.compile_schema('^APPUN.', false);
    end if;
end;
/
exec sys.dbms_session.modify_package_state(sys.dbms_session.reinitialize)

--
-- patch files
-- @^PREFIX.patches/5_1_4/patch_123456.sql
--
@^PREFIX.patches/5_1_4/patch_25307229.sql
@^PREFIX.patches/5_1_4/patch_25216194.sql
@^PREFIX.patches/5_1_4/patch_25227883.sql
@^PREFIX.patches/5_1_4/patch_25381119.sql
@^PREFIX.patches/5_1_4/patch_25378653.sql
@^PREFIX.patches/5_1_4/patch_25387853.sql
@^PREFIX.patches/5_1_4/patch_25427480.sql
@^PREFIX.patches/5_1_4/patch_25430809.sql
@^PREFIX.patches/5_1_4/patch_25407597.sql
@^PREFIX.patches/5_1_4/patch_24410383.sql
@^PREFIX.patches/5_1_4/patch_22067754.sql
@^PREFIX.patches/5_1_4/patch_25636767.sql
@^PREFIX.patches/5_1_4/patch_25940678.sql
@^PREFIX.patches/5_1_4/patch_26352078.sql
@^PREFIX.patches/5_1_4/patch_26802765.sql
@^PREFIX.patches/5_1_4/patch_26677460.sql

-- commit after dml changes to metadata
commit;

timing start "Install Packaged and Sample Applications"
set define '^'
@^PREFIX.core/packaged_apps/metadata.sql
set define '^'
@^PREFIX.core/packaged_apps/install_packaged_apps.sql
set define '^'
prompt
timing stop
