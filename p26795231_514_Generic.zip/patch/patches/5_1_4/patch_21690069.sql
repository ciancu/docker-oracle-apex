set define '^' verify off
prompt ...patch_21690069.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_21690069.sql
--
-- MODIFIED   (MM/DD/YYYY)
--   cbcho     09/28/2017 - Created
--   cbcho     09/29/2017 - Changed no wait to skip locked
--
--------------------------------------------------------------------------------
prompt ...trigger wwv_flow_ws_conditions_t1

create or replace trigger wwv_flow_ws_conditions_t1
    before insert or update on wwv_flow_worksheet_conditions
    for each row
begin
    --
    -- maintain pk and timestamps
    --
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if inserting then
        :new.created_on := sysdate;
        :new.created_by := nvl(wwv_flow.g_user,user);
        :new.updated_on := sysdate;
        :new.updated_by := nvl(wwv_flow.g_user,user);
    elsif updating then
        :new.updated_on := sysdate;
        :new.updated_by := nvl(wwv_flow.g_user,user);
    end if;
    if inserting and :new.enabled is null then
        :new.enabled := 'Y';
    end if;
    if inserting and :new.allow_delete is null then
        :new.allow_delete := 'Y';
    end if;

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := wwv_flow.get_sgid;
    end if;

    if not wwv_flow.g_import_in_progress then
        --
        -- update parent timestamp
        --
        for i in ( select rowid
                     from wwv_flow_worksheet_rpts
                    where id = :new.report_id
                    for update skip locked )
        loop
            update wwv_flow_worksheet_rpts
               set updated_on = :new.updated_on,
                   updated_by = :new.updated_by
             where id = :new.report_id;
        end loop;
    end if;
end;
/
show errors
