set define '^' verify off
prompt ...patch_25381119.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25381119.sql
--
--    DESCRIPTION
--      Amend source query for page processes on pg 4000:205
--
--    MODIFIED   (MM/DD/YYYY)
--    hfarrell    13/01/2017 - Created
--
--------------------------------------------------------------------------------

declare
    l_code clob;
begin

    -- Compute PK's page process
    l_code := wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_pk1 wwv_flow_global.t_dbms_id := ''ROWID'';',
'  l_pk2 wwv_flow_global.t_dbms_id := null;',
'  l_fk  varchar2(1000)            := '''';',
'begin',
'',
'for c1 in ( select cc.column_name  ',
'              from sys.dba_constraints c, sys.dba_cons_columns cc',
'             where c.constraint_name = cc.constraint_name',
'               and c.owner = cc.owner',
'               and c.table_name = cc.table_name',
'               and c.constraint_type = ''R''',
'               and c.table_name = :P205_TABLE_NAME',
'               and c.owner = :P3000_SCHEMA',
'             order by position',
') loop',
'    if c1.column_name is not null then',
'        l_fk := l_fk||'':''||c1.column_name;',
'    end if;',
'end loop;',
'',
'',
'for c2 in ( select cc.column_name, cc.position  ',
'              from sys.dba_constraints c, sys.dba_cons_columns cc',
'             where c.constraint_name = cc.constraint_name',
'               and c.owner = cc.owner',
'               and c.table_name = cc.table_name',
'               and c.constraint_type = ''P''',
'               and c.table_name = :P205_TABLE_NAME',
'               and c.owner = :P3000_SCHEMA',
'             order by position',
') loop',
'    if (c2.position = 1) then',
'        l_pk1 := c2.column_name;',
'    elsif (c2.position = 2) then',
'        -- Table with 2 PKs and one of the PKs is a FK',
'        if (instr(l_fk,l_pk1) > 0 or instr(l_fk,c2.column_name) > 0 ) then',
'',
'            l_pk1 := ''ROWID'';',
'            l_pk2 := null;',
'        else',
'            l_pk2 := c2.column_name;',
'        end if;',
'    elsif (c2.position = 3) then --more than 2 pk''s so go back to using ROWID',
'        l_pk1 := ''ROWID'';',
'        l_pk2 := null;',
'        exit;',
'    end if;',
'end loop;',
'',
'--if the pk is an identity always column, set pk back to ROWID',
'if wwv_flow_wizard_api.is_identity_always(:P3000_SCHEMA,:P205_TABLE_NAME,l_pk1) then',
'    l_pk1 := ''ROWID'';',
'    l_pk2 := null;',
'end if;',
'',
'  :P205_PK1 := l_pk1;',
'  :P205_PK2 := l_pk2;',
'end;'));
    
    update wwv_flow_step_processing
       set process_sql_clob = l_code
     where flow_id              between 4000 and 4009
       and flow_step_id         >= 205
       and flow_step_id         < 205 + 1
       and id                   >= 399232077991657515 
       and id                   < 399232077991657515 + 1
       and security_group_id    = 10;
    
    -- Compute MasterDetails PK's page process
    l_code := wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_pk1 wwv_flow_global.t_dbms_id := ''ROWID'';',
'  l_pk2 wwv_flow_global.t_dbms_id := null;',
'begin',
'for c1 in ( select cc.column_name, cc.position  ',
'              from sys.dba_constraints c, sys.dba_cons_columns cc',
'             where c.constraint_name = cc.constraint_name',
'               and c.owner = cc.owner',
'               and c.table_name = cc.table_name',
'               and c.constraint_type = ''P''',
'               and c.table_name = :P205_MASTER_TABLE_NAME',
'               and c.owner = :P3000_SCHEMA',
'             order by position',
') loop',
'    if (c1.position = 1) then',
'        l_pk1 := c1.column_name;',
'    elsif (c1.position = 2) then',
'        l_pk2 := c1.column_name;',
'    elsif (c1.position = 3) then --more than 2 pk''s so go back to using ROWID',
'        l_pk1 := ''ROWID'';',
'        l_pk2 := null;',
'        exit;',
'    end if;',
'end loop;',
'  :P205_PK1 := l_pk1;',
'  :P205_PK2 := l_pk2;',
'end;'));

    update wwv_flow_step_processing
       set process_sql_clob = l_code
     where flow_id              between 4000 and 4009
       and flow_step_id         >= 205
       and flow_step_id         < 205 + 1
       and id                   >= 399232215976657518 
       and id                   < 399232215976657518 + 1
       and security_group_id    = 10;

       
end;
/
commit
/