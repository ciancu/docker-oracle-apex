set define '^' verify off
prompt ...patch_25940678.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
-- NAME
--   patch_25940678.sql
--
-- DESCRIPTION
--   Re-enable items on 4350:56 before submit, so they get sent to the server.
--
-- MODIFIED   (MM/DD/YYYY)
--   cneumuel  05/11/2017 - Created
--   cneumuel  05/31/2017 - Explicitly disable fieldset #P56_DEVELOPER (bug #25940678)
--
--------------------------------------------------------------------------------

--
-- JavaScript on 4350:56 to submit disabled items
--
update ( select javascript_code_onload,
                unistr('\000a') LF
           from wwv_flow_steps
          where security_group_id = 10
            and flow_id           between 4350 and 4359
            and id                between 56   and 56.9999 )
   set javascript_code_onload = 'apex.jQuery(document).on ('||LF||
                                '    "apexpagesubmit",'||LF||
                                '    function() {'||LF||
                                '        $(":disabled").removeAttr("disabled");'||LF||
                                '        $("#P56_DEVELOPER").removeAttr("disabled");'||LF||
                                '    });'
/

commit
/
