set define '^' verify off
prompt ...patch_25489827.sql

Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     02/02/2017 - Created patch file for bug 25489827

begin
    wwv_flow_security.g_security_group_id := 10;

    update wwv_flows
       set substitution_value_01 = decode(substitution_string_01,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_01,'2016','2017'),substitution_value_01),
           substitution_value_02 = decode(substitution_string_02,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_02,'2016','2017'),substitution_value_02),
           substitution_value_03 = decode(substitution_string_03,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_03,'2016','2017'),substitution_value_03),
           substitution_value_04 = decode(substitution_string_04,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_04,'2016','2017'),substitution_value_04),
           substitution_value_05 = decode(substitution_string_05,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_05,'2016','2017'),substitution_value_05),
           substitution_value_06 = decode(substitution_string_06,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_06,'2016','2017'),substitution_value_06),
           substitution_value_07 = decode(substitution_string_07,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_07,'2016','2017'),substitution_value_07),
           substitution_value_08 = decode(substitution_string_08,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_08,'2016','2017'),substitution_value_08),
           substitution_value_09 = decode(substitution_string_09,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_09,'2016','2017'),substitution_value_09),
           substitution_value_10 = decode(substitution_string_10,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_10,'2016','2017'),substitution_value_10),
           substitution_value_11 = decode(substitution_string_11,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_11,'2016','2017'),substitution_value_11),
           substitution_value_12 = decode(substitution_string_12,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_12,'2016','2017'),substitution_value_12),
           substitution_value_13 = decode(substitution_string_13,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_13,'2016','2017'),substitution_value_13),
           substitution_value_14 = decode(substitution_string_14,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_14,'2016','2017'),substitution_value_14),
           substitution_value_15 = decode(substitution_string_15,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_15,'2016','2017'),substitution_value_15),
           substitution_value_16 = decode(substitution_string_16,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_16,'2016','2017'),substitution_value_16),
           substitution_value_17 = decode(substitution_string_17,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_17,'2016','2017'),substitution_value_17),
           substitution_value_18 = decode(substitution_string_18,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_18,'2016','2017'),substitution_value_18),
           substitution_value_19 = decode(substitution_string_19,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_19,'2016','2017'),substitution_value_19),
           substitution_value_20 = decode(substitution_string_20,'MSG_COPYRIGHT',
                                          regexp_replace(substitution_value_20,'2016','2017'),substitution_value_20)
     where id between 4000 and 5000
       and security_group_id = 10;

    commit;
end;
/
