set define '^' verify off
set concat on
set concat .

Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      deppatch.sql
Rem
Rem    DESCRIPTION
Rem      Application Express patch
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     12/22/2016 - Created
Rem    hfarrell    01/23/2017 - Added apex_views.sql (bug #25217197)
Rem    hfarrell    01/30/2017 - Added view.sql (bug #25467564)
Rem    cneumuel    02/07/2017 - Added wwv_flow_session.sql (bug #25510163)
Rem    vuvarov     03/29/2017 - Updated for APEX 5.1.2
Rem    pawolf      04/20/2017 - Added wwv_flow_plugin_api.sql
Rem    cneumuel    04/21/2017 - Added wwv_flow_cgi.sql (bug #25851470)
Rem    hfarrell    05/03/2017 - Added api.sql (bug #25991346)
Rem    pawolf      05/31/2017 - Added flow.sql (bug #25117499)
Rem    cneumuel    06/07/2017 - Added wwv_flow_crypto.sql (bug #25790200)
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    cneumuel    07/12/2017 - Added wwv_flow_security.sql (bug #26337459)
Rem    cneumuel    07/19/2017 - Added wwv_flow_maint.sql (bug #26416174)
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4
Rem    pawolf      09/27/2017 - Added wwv_flow_javascript.sql (bug #26860634)
Rem    cbcho       09/29/2017 - Added wwv_flow_worksheet_api.sql (bug #21690069)
Rem    cneumuel    10/10/2017 - Added wwv_flow_t_export_file, wwv_flow_t_export_files, {wwv_flow_export_api,wwv_flow_export_int,gen_api_pkg,wwv_flow_fnd_user_int (feature}.sql (feature #2224)
Rem                           - Added {wwv_flow_response,wwv_flow_debug}.sql
Rem    cczarski    10/11/2017 - Added wwv_flow_web_services.sql, wwv_flow_webservices_api.sql
Rem    cneumuel    10/13/2017 - Added types.sql instead of inline type decls for wwv_flow_t_export_file%
Rem                           - Added wwv_flow_jet_chart.sql
Rem    cneumuel    10/16/2017 - Create or replace public synonyms to make script re-runnable
Rem    pawolf      11/02/2017 - Added wwv_flow_json.sql (bug #26199331)
Rem    cneumuel    11/07/2017 - Added wwv_flow_char_reader.sql

define APPUN        = 'APEX_050100'
define PREFIX       = '^1'
define INSTALL_TYPE = '^2'

@^PREFIX.patches/5_1_4/prereq.sql

declare
    invalid_alter_priv exception;
    pragma exception_init(invalid_alter_priv,-02248);
begin
    execute immediate 'alter session set "_ORACLE_SCRIPT"=true';
exception
    when invalid_alter_priv then
        null;
end;
/

alter session set current_schema = ^APPUN.;

---------------------------------------------------------------------------
-- Compilation of package specifications
-- @^PREFIX.core/foo.sql
---------------------------------------------------------------------------
@^PREFIX.core/types.sql
@^PREFIX.core/flows_release.sql
@^PREFIX.core/flow.sql
@^PREFIX.core/wwv_flow_session.sql
@^PREFIX.core/wwv_flow_plugin_api.sql
@^PREFIX.core/wwv_flow_cgi.sql
@^PREFIX.core/api.sql
@^PREFIX.core/wwv_flow_crypto.sql
@^PREFIX.core/wwv_flow_security.sql
@^PREFIX.core/wwv_flow_maint.sql
@^PREFIX.core/wwv_flow_javascript.sql
@^PREFIX.core/wwv_flow_char_reader.sql
@^PREFIX.core/wwv_flow_json.sql
@^PREFIX.core/wwv_flow_worksheet_api.sql
@^PREFIX.core/wwv_flow_export_api.sql
@^PREFIX.core/wwv_flow_export_int.sql
@^PREFIX.core/gen_api_pkg.sql
@^PREFIX.core/wwv_flow_fnd_user_int.sql
@^PREFIX.core/wwv_flow_response.sql
@^PREFIX.core/wwv_flow_debug.sql
@^PREFIX.core/wwv_flow_webservices_api.sql
@^PREFIX.core/wwv_flow_web_services.sql
@^PREFIX.core/wwv_flow_jet_chart.sql

--------------------------------------------------------------------------------
-- Compilation of views
--------------------------------------------------------------------------------
@^PREFIX.core/view.sql
@^PREFIX.core/apex_views.sql

--------------------------------------------------------------------------------
-- Grants and public synonyms
--------------------------------------------------------------------------------
create or replace public synonym apex_t_export_file for wwv_flow_t_export_file;
create or replace public synonym apex_t_export_files for wwv_flow_t_export_files;
grant execute on wwv_flow_t_export_file to public;
grant execute on wwv_flow_t_export_files to public;

create or replace public synonym apex_export for wwv_flow_export_api;
grant execute on wwv_flow_export_api to public;
