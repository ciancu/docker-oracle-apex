set define '^' verify off
prompt ...patch_25216194.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25216194.sql
--
--    DESCRIPTION
--      Amend page process condition for process on 4000:4711
--
--    MODIFIED   (MM/DD/YYYY)
--    hfarrell    11/01/2017 - Created
--
--------------------------------------------------------------------------------


begin

    update wwv_flow_step_processing
       set process_when_type = null,
           process_when = null
     where flow_id              between 4000 and 4009
       and flow_step_id         >= 4711
       and flow_step_id         < 4711 + 1
       and id                   >= 16122422493262465 
       and id                   < 16122422493262465 + 1
       and security_group_id    = 10;
end;
/
commit
/
