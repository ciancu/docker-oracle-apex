set define '^' verify off
set concat on
set concat .

Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      ddlpatch.sql
Rem
Rem    DESCRIPTION
Rem      Application Express patch
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    vuvarov     12/22/2016 - Created
Rem    hfarrell    02/08/2017 - Added patch_25311325.sql (bug #25311325)
Rem    vuvarov     03/29/2017 - Updated for APEX 5.1.2
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    hfarrell    06/30/2017 - Added patch_26352078_ddl.sql (bug #26352078)
Rem    cbcho       08/04/2017 - Removed patch_26352078_ddl.sql as it no longer needs (bug #26352078)
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4

define APPUN        = 'APEX_050100'
define PREFIX       = '^1'
define INSTALL_TYPE = '^2'

@^PREFIX.patches/5_1_4/prereq.sql

declare
    invalid_alter_priv exception;
    pragma exception_init(invalid_alter_priv,-02248);
begin
    execute immediate 'alter session set "_ORACLE_SCRIPT"=true';
exception
    when invalid_alter_priv then
        null;
end;
/

alter session set current_schema = ^APPUN.;

---------------------------------------------------------------------------
-- Direct, rerunnable DDL
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- DDL changes
-- @^PREFIX.patches/5_1_4/patch_123456.sql
---------------------------------------------------------------------------
@^PREFIX.patches/5_1_4/patch_25311325.sql