set define '^' verify off
prompt ...patch_25407597.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
--
--    NAME
--      patch_25407597.sql
--
--    DESCRIPTION
--      Change display-only INTERNAL_NAME attribute text field on page 4000:267
--
--    MODIFIED   (MM/DD/YYYY)
--    msewtz     02/07/2017 - Created
--
--------------------------------------------------------------------------------


begin

    update wwv_flow_step_items
       set display_as = 'NATIVE_TEXT_FIELD',
           csize = 64,
           attribute_01 = 'N',
           attribute_02 = 'VALUE',
           attribute_04 = 'TEXT',
           attribute_05 = 'NONE'           
     where flow_id              between 4000 and 4009
       and flow_step_id         >= 267
       and flow_step_id         < 267 + 1
       and id                   >= 1331349974716223301 
       and id                   < 1331349974716223301 + 1
       and security_group_id    = 10;
end;
/
commit
/
