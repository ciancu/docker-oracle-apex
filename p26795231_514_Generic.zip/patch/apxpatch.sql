Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      apxpatch.sql
Rem
Rem    DESCRIPTION
Rem      This script installs Oracle Application Express 5.1.4 patch.
Rem
Rem    NOTES
Rem      Assumes the SYS user is connected.
Rem
Rem    REQUIREMENTS
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem     vuvarov    12/22/2016 - Created
Rem     vuvarov    03/29/2017 - Updated for APEX 5.1.2
Rem    hfarrell    06/26/2017 - Updated for APEX 5.1.3
Rem    hfarrell    09/25/2017 - Updated for APEX 5.1.4

set define '^'
set concat on
set concat .
set verify off

@@apxpreins.sql

COLUMN :script_name NEW_VALUE comp_file NOPRINT
VARIABLE script_name VARCHAR2(50)

declare
    l_script_name varchar2(100);
begin
    if '^CDB_ROOT' = 'YES' then
        l_script_name := 'apxpatch_cdb.sql';
    elsif '^CDB' = 'YES' and '^META_LINK' = 'METADATA LINK' then
        l_script_name := 'apxpatch_cdb.sql';
    else
        l_script_name := 'apxpatch_nocdb.sql';
    end if;
    :script_name := l_script_name;
end;
/

select :script_name from dual;

@@^comp_file
