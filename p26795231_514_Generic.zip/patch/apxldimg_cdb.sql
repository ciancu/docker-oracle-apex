Rem  Copyright (c) Oracle Corporation 1999 - 2017. All Rights Reserved.
Rem
Rem    NAME
Rem      apxldimg_cdb.sql
Rem
Rem    DESCRIPTION
Rem      This script will load Application Express images into XDB.
Rem
Rem    NOTES
Rem      This script should be run as SYS.
Rem
Rem    Arguments:
Rem      Position 1: The path to the directory where the Application Express patch exists on
Rem                  the filesystem.
Rem
Rem    Example:
Rem      sqlplus "sys/syspass as sysdba" @apxldimg.sql /tmp/patch
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem     jkallman   01/02/2013 - Created
Rem     vuvarov    04/05/2013 - Added support for empty files
Rem     vuvarov    04/15/2013 - Reference script arguments only once
Rem     jstraub    02/03/2014 - Invoke apxldimg_core.sql
Rem     jstraub    06/22/2015 - Created from apxldimg.sql


set define '^' verify off
set serveroutput on
set concat on
set concat .

whenever sqlerror exit

column :xe_home new_value OH_HOME NOPRINT
variable xe_home varchar2(255)

set serverout on
begin
    -- Get ORACLE_HOME
    sys.dbms_system.get_env('ORACLE_HOME',:xe_home);
    if length(:xe_home) = 0 then
        sys.dbms_output.put_line(lpad('-',80,'-'));
        raise_application_error (
            -20001,
            'Oracle Home environment variable not set' );
    end if;
end;
/
whenever sqlerror continue

set termout off
select :xe_home from sys.dual;
set termout on

prompt Performing installation in multitenant container database in the background.
prompt The installation progress is spooled into apxldimg_cdb*.log files.
prompt
prompt Please wait...
prompt

host ^OH_HOME/perl/bin/perl -I ^OH_HOME/rdbms/admin ^OH_HOME/rdbms/admin/catcon.pl -b apxldimg_cdb apxldimg_nocdb.sql --p^1

prompt
prompt Installation completed. Log files for each container can be found in:
prompt
prompt apxldimg_cdb*.log
prompt
prompt You can quickly scan for ORA errors or compilation errors by using a utility
prompt like grep:
prompt
prompt grep ORA- *.log
prompt grep PLS- *.log
prompt
